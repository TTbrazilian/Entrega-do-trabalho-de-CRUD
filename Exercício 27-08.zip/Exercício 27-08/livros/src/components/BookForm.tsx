import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createBook, getBookById, updateBook } from '../services/api';
    interface Book {     
        title: string;
        author: string;
        publication: number;
        gender: string;
        pages: number;
        }
function BookForm() {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [book, setBook] = useState<Book>({
        title: 'teste',
        author: 'teste',
        publication: 0,
        gender:'teste',
        pages: 0

    });
    useEffect(() => {
 if (id) {
    loadBook();
 }
 }, [id]);
        const loadBook = async () => {
        try {
        const response = await getBookById(id as string);
            setBook(response.data);
 } catch (error) {
 console.error("Error loading product data", error);
 }
 };
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setBook({
         ...book,
 [e.target.name]: e.target.value,
 });
 };
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
    try {
 if (id) {
    await updateBook(id, book);
 } 
 else {
    await createBook(book);
 }
    navigate('/');
 } catch (error) {
 console.error("Error saving book", error);
 }
 };
    return (
 <form onSubmit={handleSubmit}>
 <div>
 <label>Title</label>
 <input
 type="text"
 name="title"
 value={book.title}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Author</label>
 <input
 type="text"
 name="author"
 value={book.author}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Publication</label>
 <input
 type="number"
 name="publication"
 value={book.publication}
 onChange={handleChange}
 />
 </div>
    <div>
 <label>Gender</label>
 <input
 type="string"
 name="gender"
 value={book.gender}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Pages</label>
 <input
 type="number"
 name="pages"
 value={book.pages}
 onChange={handleChange}
 />
 </div>
 <button type="submit">Save</button>
 </form>
 );
}
export default BookForm;