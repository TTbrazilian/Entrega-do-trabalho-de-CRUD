import BookList from '../components/BookList';
    function Home() {
 return (
    <div>
    <h1>Book Management</h1>
        <BookList />
    </div>
 );
}
    export default Home;
