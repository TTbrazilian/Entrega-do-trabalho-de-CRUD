import BookForm from '../components/BookForm';
    function AddBook() {
    return (
 <div>
    <h1>Add Book</h1>
 <BookForm />
    </div>
 );
}
export default AddBook;