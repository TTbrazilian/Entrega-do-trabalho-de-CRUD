import BookForm from '../components/BookForm';
function EditBook() {
 return (
 <div>
    <h1>Edit Book</h1>
        <BookForm/>
    
    </div>
 );
}
export default EditBook;